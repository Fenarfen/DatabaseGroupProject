SELECT product_name, product_id, product_creation_date, product_expection_date, product_manufacture FROM Products
WHERE product_expection_date BETWEEN 01/03/2021 AND 01/7/2021;